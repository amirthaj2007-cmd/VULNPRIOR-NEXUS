import io
import unittest
import zipfile
from unittest.mock import Mock, patch

from src.repository_scanner import parse_requirements_text, scan_dependency_upload


class TestRepositoryScanner(unittest.TestCase):
    def test_pinned_requirements_are_normalized(self):
        packages, skipped = parse_requirements_text("Requests==2.31.0\nflask>=2.0\n# note\n")
        self.assertEqual(packages[0]["name"], "requests")
        self.assertEqual(packages[0]["version"], "2.31.0")
        self.assertEqual(len(skipped), 1)

    def test_zip_manifest_is_read_without_extraction(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as archive:
            archive.writestr("demo/requirements.txt", "requests==2.31.0\n")
            archive.writestr("demo/app.py", "print('not executed')")
        with patch("src.repository_scanner.requests.post") as post:
            response = Mock()
            response.raise_for_status.return_value = None
            response.json.return_value = {"results": [{"vulns": []}]}
            post.return_value = response
            result = scan_dependency_upload(buf.getvalue(), "demo.zip")
        self.assertEqual(result["status"], "success")
        self.assertEqual(len(result["packages"]), 1)
        self.assertEqual(result["packages"][0]["name"], "requests")

    def test_osv_matches_are_returned(self):
        with patch("src.repository_scanner.requests.post") as post:
            response = Mock()
            response.raise_for_status.return_value = None
            response.json.return_value = {"results": [{"vulns": [{"id": "GHSA-test", "aliases": ["CVE-2024-0001"], "summary": "Test advisory", "details": "Details", "modified": "2024-01-01", "severity": [], "affected": [], "references": []}]}]}
            post.return_value = response
            result = scan_dependency_upload(b"requests==2.31.0\n", "requirements.txt")
        self.assertEqual(len(result["findings"]), 1)
        self.assertEqual(result["findings"][0]["cve_id"], "CVE-2024-0001")

    def test_non_zip_non_txt_rejected(self):
        with self.assertRaises(ValueError):
            scan_dependency_upload(b"abc", "app.py")


if __name__ == "__main__":
    unittest.main()
