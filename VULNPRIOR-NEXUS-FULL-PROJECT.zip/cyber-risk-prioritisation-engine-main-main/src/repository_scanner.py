"""Safe, dependency-manifest based Python repository vulnerability checks.

This module does not execute uploaded code. It reads supported dependency manifests
from a requirements file or ZIP archive and queries the public OSV API for exact
package versions. Results are intelligence matches, not proof of exploitability.
"""
from __future__ import annotations

import io
import json
import re
import zipfile
from pathlib import PurePosixPath
from typing import Dict, Iterable, List, Tuple

import requests

MAX_ARCHIVE_BYTES = 20 * 1024 * 1024
MAX_MANIFEST_BYTES = 1 * 1024 * 1024
MAX_MANIFESTS = 30
SUPPORTED_MANIFESTS = {
    "requirements.txt", "requirements-dev.txt", "requirements-prod.txt",
    "pyproject.toml", "poetry.lock", "pipfile.lock"
}


def _clean_package_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name.strip()).lower()


def parse_requirements_text(text: str) -> Tuple[List[dict], List[str]]:
    """Parse the common pinned forms from requirements.txt without installing anything."""
    packages: Dict[Tuple[str, str], dict] = {}
    skipped: List[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith(("-r ", "--", "-e ")):
            continue
        line = line.split(" #", 1)[0].strip()
        match = re.match(r"^([A-Za-z0-9_.-]+)\s*(?:==|===)\s*([A-Za-z0-9!+_.-]+)\s*$", line)
        if match:
            name, version = _clean_package_name(match.group(1)), match.group(2)
            packages[(name, version)] = {"name": name, "version": version, "ecosystem": "PyPI", "manifest": "requirements.txt"}
            continue
        # A version range is useful context, but OSV needs an exact installed version.
        loose = re.match(r"^([A-Za-z0-9_.-]+)(.*)$", line)
        if loose:
            spec = loose.group(2).strip() or "(unversioned)"
            skipped.append(f"{loose.group(1)} {spec}: exact version required for reliable lookup")
        else:
            skipped.append(f"Could not parse dependency line: {line[:100]}")
    return list(packages.values()), skipped


def _parse_lock_json(text: str, manifest: str) -> Tuple[List[dict], List[str]]:
    packages = []
    skipped = []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return [], [f"{manifest}: invalid JSON"]
    # Pipfile.lock stores dependencies under default/develop; poetry-style lock files are TOML.
    if manifest == "pipfile.lock":
        for section in ("default", "develop"):
            for name, item in (data.get(section, {}) or {}).items():
                version = str(item.get("version", "")).lstrip("=")
                if version:
                    packages.append({"name": _clean_package_name(name), "version": version, "ecosystem": "PyPI", "manifest": manifest})
                else:
                    skipped.append(f"{name}: no exact version in {manifest}")
    return packages, skipped


def _parse_poetry_lock(text: str) -> Tuple[List[dict], List[str]]:
    packages = []
    # Poetry lock uses TOML [[package]] sections. Keep parsing dependency-only and conservative.
    blocks = re.split(r"(?m)^\[\[package\]\]\s*$", text)
    for block in blocks[1:]:
        name = re.search(r'(?m)^name\s*=\s*["\']([^"\']+)["\']', block)
        version = re.search(r'(?m)^version\s*=\s*["\']([^"\']+)["\']', block)
        if name and version:
            packages.append({"name": _clean_package_name(name.group(1)), "version": version.group(1), "ecosystem": "PyPI", "manifest": "poetry.lock"})
    return packages, []


def _parse_pyproject(text: str) -> Tuple[List[dict], List[str]]:
    # Parse common PEP 621 dependency arrays and Poetry dependency tables. Unpinned ranges are skipped.
    packages = []
    skipped = []
    in_project = False
    in_poetry_deps = False
    in_dependency_array = False
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("["):
            in_project = line == "[project]"
            in_poetry_deps = line == "[tool.poetry.dependencies]"
            if line not in ("[project]", "[tool.poetry.dependencies]"):
                in_dependency_array = False
        if not line or line.startswith("#"):
            continue
        if in_project and line.startswith("dependencies") and "=" in line:
            in_dependency_array = "[" in line
            # Also support a single-line array.
            array_text = line.split("=", 1)[1]
            for spec in re.findall(r'["\']([^"\']+)["\']', array_text):
                m = re.match(r"^([A-Za-z0-9_.-]+)\s*(.*)$", spec)
                if not m:
                    continue
                name, constraint = _clean_package_name(m.group(1)), m.group(2).strip()
                pinned = re.fullmatch(r"==([0-9][A-Za-z0-9!+_.-]*)", constraint)
                if pinned:
                    packages.append({"name": name, "version": pinned.group(1), "ecosystem": "PyPI", "manifest": "pyproject.toml"})
                else:
                    skipped.append(f"{name} {constraint or '(unversioned)'}: exact version required for reliable lookup")
            continue
        if in_dependency_array:
            if "]" in line:
                in_dependency_array = False
            for spec in re.findall(r'["\']([^"\']+)["\']', line):
                m = re.match(r"^([A-Za-z0-9_.-]+)\s*(.*)$", spec)
                if not m:
                    continue
                name, constraint = _clean_package_name(m.group(1)), m.group(2).strip()
                pinned = re.fullmatch(r"==([0-9][A-Za-z0-9!+_.-]*)", constraint)
                if pinned:
                    packages.append({"name": name, "version": pinned.group(1), "ecosystem": "PyPI", "manifest": "pyproject.toml"})
                else:
                    skipped.append(f"{name} {constraint or '(unversioned)'}: exact version required for reliable lookup")
            continue
        if in_poetry_deps and "=" in line:
            m = re.match(r'^["\']?([A-Za-z0-9_.-]+)["\']?\s*=\s*["\']([^"\']+)["\']', line)
            if m:
                name, spec = _clean_package_name(m.group(1)), m.group(2)
                pinned = re.fullmatch(r"(?:==|=)\s*([0-9][A-Za-z0-9!+_.-]*)", spec)
                if pinned and name != "python":
                    packages.append({"name": name, "version": pinned.group(1), "ecosystem": "PyPI", "manifest": "pyproject.toml"})
                elif name != "python":
                    skipped.append(f"{name} {spec}: exact version required for reliable lookup")
    return packages, skipped


def _extract_manifests(uploaded_bytes: bytes, filename: str) -> Tuple[List[Tuple[str, str]], List[str]]:
    if len(uploaded_bytes) > MAX_ARCHIVE_BYTES:
        raise ValueError("Upload exceeds the 20 MB safety limit.")
    if filename.lower().endswith(".txt"):
        return [("requirements.txt", uploaded_bytes.decode("utf-8", errors="replace"))], []
    if not filename.lower().endswith(".zip"):
        raise ValueError("Upload a requirements.txt file or a ZIP containing supported Python dependency manifests.")
    manifests, warnings = [], []
    try:
        with zipfile.ZipFile(io.BytesIO(uploaded_bytes)) as archive:
            for info in archive.infolist():
                if info.is_dir():
                    continue
                # Never extract files. Ignore path traversal entries and only read known manifest basenames.
                path = PurePosixPath(info.filename)
                if path.is_absolute() or ".." in path.parts:
                    continue
                basename = path.name.lower()
                if basename not in SUPPORTED_MANIFESTS:
                    continue
                if info.file_size > MAX_MANIFEST_BYTES:
                    warnings.append(f"Skipped oversized manifest: {info.filename}")
                    continue
                if len(manifests) >= MAX_MANIFESTS:
                    warnings.append("Manifest limit reached; remaining manifests were ignored.")
                    break
                with archive.open(info) as stream:
                    manifests.append((basename, stream.read(MAX_MANIFEST_BYTES + 1).decode("utf-8", errors="replace")))
    except zipfile.BadZipFile as exc:
        raise ValueError("The uploaded file is not a valid ZIP archive.") from exc
    if not manifests:
        raise ValueError("No supported dependency manifest found. Include requirements.txt, poetry.lock, Pipfile.lock, or pyproject.toml.")
    return manifests, warnings


def scan_dependency_upload(uploaded_bytes: bytes, filename: str, timeout: int = 12) -> dict:
    manifests, warnings = _extract_manifests(uploaded_bytes, filename)
    packages: Dict[Tuple[str, str], dict] = {}
    skipped: List[str] = []
    for manifest, text in manifests:
        if manifest.startswith("requirements"):
            found, notes = parse_requirements_text(text)
        elif manifest == "poetry.lock":
            found, notes = _parse_poetry_lock(text)
        elif manifest == "pipfile.lock":
            found, notes = _parse_lock_json(text, manifest)
        else:
            found, notes = _parse_pyproject(text)
        packages.update({(p["name"], p["version"]): p for p in found})
        skipped.extend(notes)
    package_list = list(packages.values())
    if not package_list:
        return {"status": "no_pinned_dependencies", "packages": [], "findings": [], "skipped": skipped, "warnings": warnings, "manifests": [m for m, _ in manifests]}

    queries = [{"package": {"name": p["name"], "ecosystem": p["ecosystem"]}, "version": p["version"]} for p in package_list]
    findings = []
    try:
        response = requests.post("https://api.osv.dev/v1/querybatch", json={"queries": queries}, timeout=timeout)
        response.raise_for_status()
        payload = response.json().get("results", [])
    except (requests.RequestException, ValueError) as exc:
        return {"status": "offline", "packages": package_list, "findings": [], "skipped": skipped, "warnings": warnings + [f"OSV lookup failed: {exc}"], "manifests": [m for m, _ in manifests]}

    for package, result in zip(package_list, payload):
        for vuln in result.get("vulns", []) or []:
            cvss = None
            severity = str((vuln.get("database_specific", {}) or {}).get("severity", "UNKNOWN")).upper()
            for sev in vuln.get("severity", []) or []:
                score = sev.get("score", "")
                if score:
                    cvss = score
                    break
            # If OSV provides a numeric base score, derive a conventional CVSS severity band.
            try:
                numeric_score = float(cvss)
                severity = "CRITICAL" if numeric_score >= 9 else "HIGH" if numeric_score >= 7 else "MEDIUM" if numeric_score >= 4 else "LOW"
            except (TypeError, ValueError):
                pass
            details = (vuln.get("details") or "").strip().replace("\n", " ")
            aliases = vuln.get("aliases", []) or []
            cve = next((a for a in aliases if a.startswith("CVE-")), vuln.get("id", "OSV record"))
            findings.append({
                "package": package["name"], "version": package["version"],
                "vulnerability_id": vuln.get("id", "Unknown"), "cve_id": cve,
                "aliases": ", ".join(aliases[:5]), "summary": vuln.get("summary") or details[:280] or "No summary supplied by OSV.",
                "severity": severity, "cvss_vector_or_score": cvss or "Not provided",
                "modified": vuln.get("modified", ""), "references": [r.get("url", "") for r in (vuln.get("references", []) or [])[:4]],
                "fixed_versions": sorted({v for affected in (vuln.get("affected", []) or []) for r in (affected.get("ranges", []) or []) for ev in (r.get("events", []) or []) for k, v in ev.items() if k == "fixed"}),
                "source": "OSV API", "assessment_note": "Known-vulnerability match for the declared package version; validate applicability and fix compatibility before remediation."
            })
    return {"status": "success", "packages": package_list, "findings": findings, "skipped": skipped, "warnings": warnings, "manifests": [m for m, _ in manifests]}
