# VULNPRIOR NEXUS — Cyber Risk Intelligence Platform

VULNPRIOR NEXUS upgrades the original organisation-aware vulnerability prioritisation engine with a redesigned Streamlit command center, dependency-manifest scanning against OSV, interactive risk visualisations, filtering, CSV/JSON exports, PDF assessment reports, analytics, and a university demo-readiness workflow.

## Highlights

- **Organisation-aware prioritisation:** retains the original deterministic CVSS + CISA KEV + EPSS weighted scoring model.
- **Explainable findings:** shows the dominant scoring signal, contribution breakdown, and recommended next steps from the existing explanation engine.
- **Python dependency scanner:** accepts `requirements.txt` or a ZIP containing `requirements.txt`, `requirements-dev.txt`, `requirements-prod.txt`, `poetry.lock`, `Pipfile.lock`, or `pyproject.toml`.
- **OSV intelligence lookup:** checks exact pinned package versions against the public OSV API. The uploaded source code is not executed or sent to OSV; package names and versions are queried.
- **Security analytics:** risk distribution, scoring weights, ranked findings, search/filter controls, and CSV/JSON exports.
- **Demo readiness:** built-in demonstration checklist, architecture explanation, viva practice answers, and a separate demo guide.
- **Browser companion:** multi-section offline dashboard with an optional live OSV lookup for exact pinned `requirements.txt` dependencies; full ZIP and additional manifest support remains in the Python app.
- **PDF reporting:** exports current organisation findings and the latest dependency scan when available.
- **Safer upload handling:** reads ZIP manifests in memory, does not extract archives, ignores path traversal entries, and limits upload/manifest sizes.

## Quick preview without installing anything

Open `OPEN_DASHBOARD.html` in a browser for an offline interactive dashboard companion. It supports organisation profiles, search and filters, risk scoring from the bundled sample dataset, CSV export, and browser print-to-PDF. It does not run live OSV dependency lookups or repository scans.

## Run locally (Windows)

1. Extract the ZIP file.
2. Open the extracted project folder in Command Prompt or PowerShell.
3. Create and activate a virtual environment (recommended):

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

4. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Start the dashboard:

   ```powershell
   python -m streamlit run app.py
   ```

The app should open in your browser. Use the organisation selector in the sidebar, then explore the Command overview, Repository scanner, Vulnerability explorer, and Methodology tabs.

## Repository scan coverage and limitations

The scanner performs dependency-manifest matching, not a complete source-code security audit. Exact pinned versions provide the most reliable OSV queries. Unpinned dependencies are listed as skipped because the scanner cannot safely infer the installed version from a range. The scan requires internet access to query OSV. An OSV connection failure is shown as a failed lookup, not a clean bill of health.

OSV matches are displayed as a separate repository-scan result set. They are not silently blended into the existing CVSS/KEV/EPSS profile score because the two data sources do not necessarily provide equivalent fields or asset mappings. Treat matches as investigation leads, validate applicability, and test upgrades before deploying fixes.

The risk score is a deterministic prioritisation aid, not a calibrated probability of compromise. The supplied local dataset and organisation profiles are retained for the original assessment workflow.

## Tests

From the project root:

```powershell
python -m unittest tests.test_data_loader tests.test_explanations tests.test_pipeline tests.test_ranking tests.test_scoring tests.test_repository_scanner -v
```

The UI test (`tests.test_app`) imports Streamlit, so run the full suite after installing requirements.


## University demonstration

Use [DEMO_GUIDE.md](DEMO_GUIDE.md) for a five-minute walkthrough, evaluation criteria, and viva preparation. The browser companion can query OSV for exact pinned requirements when internet access and browser CORS permissions allow it. Use the Python/Streamlit app for the complete ZIP-based manifest scanner and PDF assessment workflow.
