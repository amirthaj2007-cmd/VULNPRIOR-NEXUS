# VULNPRIOR NEXUS — University Demo Guide

## 5-minute presentation flow

1. **Context:** vulnerability feeds produce too many findings to remediate in arbitrary order. VULNPRIOR NEXUS ranks findings using organisation-aware CVSS, CISA KEV, and EPSS signals.
2. **Profile selection:** choose an organisation profile and explain that in-scope products and weights differ by context.
3. **Risk overview:** point out risk bands, top findings, and the reason a finding ranks highly. A score is a triage aid, not a probability of compromise.
4. **Repository scan:** upload a project ZIP or requirements file. The scanner reads supported dependency manifests without executing uploaded code and queries OSV for exact pinned versions.
5. **Evidence:** show advisory IDs, package versions, fixed-version hints, skipped dependencies, warnings, and exports. A failed lookup must never be presented as a clean result.
6. **Reporting:** generate the PDF assessment and export findings/inventory.
7. **Limitations:** explain that this is dependency-manifest scanning, not a complete source-code, secret, runtime, reachability, or exploit-chain audit.

## Suggested evaluation criteria

- Deterministic ranking for the same data and profile.
- Correct profile-specific in-scope filtering and score ordering.
- Clear separation of CVSS severity, EPSS likelihood, and KEV known-exploitation signal.
- Parser behavior for pinned, unpinned, malformed, and duplicate requirements.
- OSV timeout/network failure reported distinctly from no matches.
- PDF/CSV/JSON evidence exports are reproducible.

## Common viva questions

**Why use multiple signals?** CVSS, EPSS, and KEV describe different dimensions of risk; combining them supports more contextual triage.

**Does the score mean chance of compromise?** No. It is a deterministic prioritisation score, not a calibrated probability.

**What is the scan boundary?** Supported dependency manifests and exact package versions are checked against OSV. Source files are not executed.

**Does no OSV match mean secure?** No. It means no match was returned for the versions and advisories queried; coverage and connectivity limits remain.
